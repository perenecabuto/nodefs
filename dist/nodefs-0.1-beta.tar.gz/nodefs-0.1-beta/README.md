nodefs
=======

Generic fuse fs mapper for any purpose